<?php
// include('index.html');
$server="localhost";
$username="root";
$password="";
$db="info";
$con=mysqli_connect($server,$username,$password,$db);
// if($con)
// {
//     echo("Connection Establish");
// }
// else
// {
//     echo("Not Establish");
// }




?>